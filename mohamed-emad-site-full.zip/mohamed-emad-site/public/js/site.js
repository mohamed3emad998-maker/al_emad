(function () {
  // Departure-board codes: render letters, then a short flip on load
  var codes = document.querySelectorAll('.code');
  var reduce = false;
  try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
  var A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  codes.forEach(function (el, row) {
    var code = el.getAttribute('data-code');
    el.setAttribute('aria-label', code);
    code.split('').forEach(function (ch, i) {
      var cell = document.createElement('i');
      cell.textContent = ch;
      cell.setAttribute('aria-hidden', 'true');
      el.appendChild(cell);
      if (reduce) return;
      var ticks = 6 + row + i * 2;
      var t = setInterval(function () {
        ticks--;
        cell.textContent = ticks > 0 ? A[Math.floor(Math.random() * 26)] : ch;
        if (ticks <= 0) clearInterval(t);
      }, 55);
    });
  });

  // Hero video: respect reduced motion, offer pause/play
  var v = document.getElementById('heroVideo');
  var vb = document.getElementById('videoToggle');
  if (v && vb) {
    var setState = function (playing) {
      vb.setAttribute('aria-pressed', playing ? 'false' : 'true');
      vb.querySelector('.vt-icon').textContent = playing ? '❚❚' : '▶';
      vb.querySelector('.vt-label').textContent = playing ? 'إيقاف الفيديو' : 'تشغيل الفيديو';
    };
    var tryPlay = function () {
      try {
        var p = v.play();
        if (p && p.catch) p.catch(function () { setState(false); });
        setState(true);
      } catch (e) { setState(false); }
    };
    if (reduce) { v.removeAttribute('autoplay'); v.pause(); setState(false); } else { tryPlay(); }
    vb.addEventListener('click', function () {
      if (v.paused) { tryPlay(); } else { v.pause(); setState(false); }
    });
  }

  // Sudan local time
  var clock = document.getElementById('clock');
  function tick() {
    try {
      clock.textContent = new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Khartoum' }).format(new Date());
    } catch (e) {
      var d = new Date(Date.now() + 2 * 3600 * 1000);
      clock.textContent = String(d.getUTCHours()).padStart(2, '0') + ':' + String(d.getUTCMinutes()).padStart(2, '0');
    }
  }
  if (clock) { tick(); setInterval(tick, 20000); }

  // Copy phone number
  var btn = document.getElementById('copyBtn');
  var msg = document.getElementById('copyMsg');
  var phone = document.getElementById('phone');
  function selectPhone() {
    try {
      var r = document.createRange(); r.selectNodeContents(phone);
      var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    } catch (e) {}
  }
  if (btn && phone && msg) btn.addEventListener('click', function () {
    var text = (phone.getAttribute('data-copy') || phone.textContent).trim();
    var done = function () { msg.textContent = 'تم نسخ الرقم'; };
    var fail = function () { selectPhone(); msg.textContent = 'تم تحديد الرقم، اضغط نسخ من جهازك'; };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, fail);
      } else { fail(); }
    } catch (e) { fail(); }
  });
})();
