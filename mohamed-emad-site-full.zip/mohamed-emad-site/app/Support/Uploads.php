<?php

namespace App\Support;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;

/**
 * Stores uploads directly under public/uploads so the site works on shared
 * hosting without `php artisan storage:link`. Paths are saved relative to
 * public/ (e.g. "uploads/abc.jpg") and rendered with asset().
 */
class Uploads
{
    public static function store(UploadedFile $file): string
    {
        $dir = public_path('uploads');

        if (! is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $extension = strtolower($file->guessExtension() ?: $file->getClientOriginalExtension() ?: 'bin');
        $name = Str::random(24).'.'.$extension;
        $file->move($dir, $name);

        return 'uploads/'.$name;
    }

    /** Delete a previously uploaded file. Bundled defaults under media/ are never removed. */
    public static function delete(?string $path): void
    {
        if (! $path || ! str_starts_with($path, 'uploads/') || str_contains($path, '..')) {
            return;
        }

        $full = public_path($path);

        if (is_file($full)) {
            @unlink($full);
        }
    }
}
