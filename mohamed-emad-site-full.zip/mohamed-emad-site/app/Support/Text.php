<?php

namespace App\Support;

use Illuminate\Support\Collection;

class Text
{
    /** Split a textarea value into trimmed, non-empty lines. */
    public static function lines(?string $text): Collection
    {
        return collect(preg_split('/\r\n|\r|\n/', (string) $text))
            ->map(fn ($line) => trim($line))
            ->filter(fn ($line) => $line !== '')
            ->values();
    }
}
