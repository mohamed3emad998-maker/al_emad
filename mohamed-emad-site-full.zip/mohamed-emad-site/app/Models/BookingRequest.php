<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BookingRequest extends Model
{
    public const STATUSES = [
        'new' => 'جديد',
        'contacted' => 'تم التواصل',
        'done' => 'مكتمل',
        'cancelled' => 'ملغي',
    ];

    protected $guarded = ['id'];

    protected $casts = [
        'travel_date' => 'date',
        'travelers' => 'integer',
    ];

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status] ?? $this->status;
    }
}
