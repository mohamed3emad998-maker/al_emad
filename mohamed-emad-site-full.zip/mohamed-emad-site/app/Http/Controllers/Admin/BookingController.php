<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BookingRequest;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BookingController extends Controller
{
    public function index(Request $request)
    {
        $status = $request->query('status');
        $query = BookingRequest::latest();

        if (array_key_exists((string) $status, BookingRequest::STATUSES)) {
            $query->where('status', $status);
        } else {
            $status = null;
        }

        $counts = BookingRequest::selectRaw('status, count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return view('admin.bookings.index', [
            'bookings' => $query->paginate(20)->withQueryString(),
            'status' => $status,
            'counts' => $counts,
            'all' => $counts->sum(),
        ]);
    }

    public function show(BookingRequest $booking)
    {
        return view('admin.bookings.show', ['booking' => $booking]);
    }

    public function update(Request $request, BookingRequest $booking)
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(array_keys(BookingRequest::STATUSES))],
            'admin_notes' => 'nullable|string|max:5000',
        ]);

        $booking->update($data);

        return redirect()
            ->route('admin.bookings.show', $booking)
            ->with('status', 'تم تحديث الطلب.');
    }

    public function destroy(BookingRequest $booking)
    {
        $booking->delete();

        return redirect()
            ->route('admin.bookings.index')
            ->with('status', 'تم حذف الطلب.');
    }
}
