<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BookingRequest;

class DashboardController extends Controller
{
    public function __invoke()
    {
        $counts = [];

        foreach (config('cms.resources') as $slug => $resource) {
            $counts[$slug] = [
                'label' => $resource['label'],
                'total' => $resource['model']::count(),
                'active' => $resource['model']::where('is_active', true)->count(),
            ];
        }

        return view('admin.dashboard', [
            'newBookings' => BookingRequest::where('status', 'new')->count(),
            'totalBookings' => BookingRequest::count(),
            'latest' => BookingRequest::latest()->take(6)->get(),
            'counts' => $counts,
        ]);
    }
}
