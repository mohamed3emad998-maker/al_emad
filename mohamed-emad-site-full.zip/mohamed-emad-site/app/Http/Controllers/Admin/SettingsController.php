<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Support\Uploads;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    private const RULES = [
        'text' => 'nullable|string|max:255',
        'textarea' => 'nullable|string|max:5000',
        'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
        'video' => 'nullable|file|mimetypes:video/mp4,video/webm|max:51200',
    ];

    public function edit(?string $group = null)
    {
        $groups = config('cms.settings');
        $group ??= array_key_first($groups);
        abort_unless(isset($groups[$group]), 404);

        return view('admin.settings', [
            'groups' => $groups,
            'group' => $group,
            'fields' => $groups[$group]['fields'],
            'values' => Setting::map(),
        ]);
    }

    public function update(Request $request, string $group)
    {
        $groups = config('cms.settings');
        abort_unless(isset($groups[$group]), 404);
        $fields = $groups[$group]['fields'];

        $rules = [];
        $attributes = [];
        foreach ($fields as $key => $field) {
            $rules[$key] = self::RULES[$field['type']] ?? self::RULES['text'];
            $attributes[$key] = $field['label'];
        }

        $data = $request->validate($rules, [], $attributes);

        foreach ($fields as $key => $field) {
            if (in_array($field['type'], ['image', 'video'], true)) {
                if ($request->hasFile($key)) {
                    Uploads::delete(Setting::where('key', $key)->value('value'));
                    Setting::put($key, Uploads::store($request->file($key)));
                } elseif ($request->boolean("remove_{$key}")) {
                    Uploads::delete(Setting::where('key', $key)->value('value'));
                    Setting::put($key, null);
                }

                continue;
            }

            Setting::put($key, $data[$key] ?? null);
        }

        return redirect()
            ->route('admin.settings.edit', $group)
            ->with('status', 'تم حفظ التغييرات.');
    }
}
