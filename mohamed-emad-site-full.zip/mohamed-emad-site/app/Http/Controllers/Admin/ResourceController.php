<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Support\Uploads;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * One controller for every list defined in config/cms.php "resources".
 */
class ResourceController extends Controller
{
    public function index(string $resource)
    {
        $r = $this->resource($resource);

        return view('admin.resource.index', [
            'r' => $r,
            'items' => $r['model']::ordered()->get(),
        ]);
    }

    public function create(string $resource)
    {
        $r = $this->resource($resource);
        $item = new $r['model'];
        $item->is_active = true;
        $item->sort_order = ((int) $r['model']::max('sort_order')) + 10;

        return view('admin.resource.form', ['r' => $r, 'item' => $item]);
    }

    public function store(Request $request, string $resource)
    {
        $r = $this->resource($resource);
        $item = new $r['model'];
        $item->fill($this->validated($request, $r, $item))->save();

        return redirect()
            ->route('admin.resource.index', $r['slug'])
            ->with('status', "تمت إضافة {$r['singular']}.");
    }

    public function edit(string $resource, int $id)
    {
        $r = $this->resource($resource);

        return view('admin.resource.form', [
            'r' => $r,
            'item' => $r['model']::findOrFail($id),
        ]);
    }

    public function update(Request $request, string $resource, int $id)
    {
        $r = $this->resource($resource);
        $item = $r['model']::findOrFail($id);
        $item->fill($this->validated($request, $r, $item))->save();

        return redirect()
            ->route('admin.resource.index', $r['slug'])
            ->with('status', 'تم حفظ التغييرات.');
    }

    public function destroy(string $resource, int $id)
    {
        $r = $this->resource($resource);
        $item = $r['model']::findOrFail($id);

        foreach ($r['fields'] as $name => $field) {
            if ($field['type'] === 'image') {
                Uploads::delete($item->{$name});
            }
        }

        $item->delete();

        return redirect()
            ->route('admin.resource.index', $r['slug'])
            ->with('status', "تم حذف {$r['singular']}.");
    }

    private function resource(string $slug): array
    {
        $r = config("cms.resources.{$slug}");
        abort_unless(is_array($r), 404);
        $r['slug'] = $slug;

        return $r;
    }

    private function validated(Request $request, array $r, Model $item): array
    {
        $rules = [];
        $attributes = [];

        foreach ($r['fields'] as $name => $field) {
            $attributes[$name] = $field['label'];

            $rules[$name] = match ($field['type']) {
                'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
                'boolean' => 'nullable',
                'icon' => ['required', 'string', Rule::in(array_keys(config('cms.icons')))],
                default => $field['rules'] ?? 'nullable|string|max:255',
            };
        }

        $data = $request->validate($rules, [], $attributes);

        foreach ($r['fields'] as $name => $field) {
            switch ($field['type']) {
                case 'boolean':
                    $data[$name] = $request->boolean($name);
                    break;

                case 'number':
                    $data[$name] = (int) ($data[$name] ?? 0);
                    break;

                case 'image':
                    unset($data[$name]);
                    if ($request->hasFile($name)) {
                        Uploads::delete($item->{$name});
                        $data[$name] = Uploads::store($request->file($name));
                    } elseif ($request->boolean("remove_{$name}")) {
                        Uploads::delete($item->{$name});
                        $data[$name] = null;
                    }
                    break;
            }
        }

        if (isset($data['code']) && is_string($data['code'])) {
            $data['code'] = strtoupper($data['code']);
        }

        return $data;
    }
}
