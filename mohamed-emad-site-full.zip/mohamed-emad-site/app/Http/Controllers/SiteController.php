<?php

namespace App\Http\Controllers;

use App\Models\BookingRequest;
use App\Models\Destination;
use App\Models\DocumentGroup;
use App\Models\Faq;
use App\Models\Feature;
use App\Models\Service;
use App\Models\Setting;
use App\Models\Step;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SiteController extends Controller
{
    public function home()
    {
        return view('site.home', [
            's' => Setting::map(),
            'services' => Service::visible()->get(),
            'features' => Feature::visible()->get(),
            'destinations' => Destination::visible()->get(),
            'documents' => DocumentGroup::visible()->get(),
            'steps' => Step::visible()->get(),
            'faqs' => Faq::visible()->get(),
        ]);
    }

    public function book(Request $request)
    {
        $back = route('home').'#booking';

        // Honeypot: real visitors never fill the hidden "website" field.
        if (filled($request->input('website'))) {
            return redirect()->to($back)->with('booked', true);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:120',
            'phone' => 'required|string|max:40',
            'service' => 'nullable|string|max:120',
            'destination' => 'nullable|string|max:120',
            'travel_date' => 'nullable|date|after_or_equal:today',
            'travelers' => 'nullable|integer|min:1|max:200',
            'notes' => 'nullable|string|max:2000',
        ]);

        if ($validator->fails()) {
            return redirect()->to($back)->withErrors($validator)->withInput();
        }

        BookingRequest::create($validator->validated() + ['status' => 'new']);

        return redirect()->to($back)->with('booked', true);
    }
}
