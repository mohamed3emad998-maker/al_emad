<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(CmsSeeder::class);

        $email = env('ADMIN_EMAIL');
        $password = env('ADMIN_PASSWORD');

        if (User::where('email', $email ?: 'admin@example.com')->exists()) {
            $this->command?->info('Admin user already exists; password unchanged.');

            return;
        }

        if (! $email || ! $password) {
            $email = $email ?: 'admin@example.com';
            $password = Str::password(14, symbols: false);
            $this->command?->warn('ADMIN_EMAIL / ADMIN_PASSWORD not set in .env. Created admin with a generated password:');
            $this->command?->line("  Email:    {$email}");
            $this->command?->line("  Password: {$password}");
            $this->command?->warn('Copy it now and change it from the admin panel after logging in.');
        }

        User::create([
            'name' => 'مدير الموقع',
            'email' => $email,
            'password' => $password, // hashed by the User model's "hashed" cast
        ]);
    }
}
