<?php

/*
|--------------------------------------------------------------------------
| CMS definition
|--------------------------------------------------------------------------
| The admin panel is generated from this file:
|  - "settings": single values (texts, photos, video) grouped into tabs.
|  - "resources": lists of items (services, destinations, ...) with full CRUD.
| Field types: text, textarea, lines (one item per line), number, boolean,
|              image, video, icon.
*/

return [

    'icons' => [
        'ticket' => 'تذكرة طيران',
        'plane' => 'طائرة',
        'hotel' => 'فندق',
        'passport' => 'جواز سفر',
        'kaaba' => 'الكعبة',
        'sun' => 'شمس / سياحة',
        'car' => 'سيارة',
        'user' => 'شخص',
        'receipt' => 'فاتورة',
        'pin' => 'موقع',
        'headset' => 'دعم',
        'shield' => 'حماية',
        'star' => 'نجمة',
        'check' => 'علامة صح',
        'phone' => 'هاتف',
    ],

    'settings' => [
        'company' => [
            'label' => 'بيانات الشركة',
            'fields' => [
                'company_name' => ['label' => 'اسم الشركة الكامل', 'type' => 'text'],
                'brand_name' => ['label' => 'الاسم في الشعار', 'type' => 'text'],
                'company_short' => ['label' => 'الحروف داخل الدائرة', 'type' => 'text', 'hint' => 'حرفان أو ثلاثة، مثل: م ع'],
                'tagline' => ['label' => 'النشاط', 'type' => 'text'],
                'city' => ['label' => 'المدينة', 'type' => 'text'],
                'address' => ['label' => 'العنوان', 'type' => 'text'],
                'phone' => ['label' => 'رقم الهاتف كما يظهر', 'type' => 'text', 'hint' => 'مثل: 0121669942'],
                'phone_intl' => ['label' => 'رقم الهاتف الدولي', 'type' => 'text', 'hint' => 'أرقام فقط بدون + أو صفر البداية، مثل: 249121669942'],
                'whatsapp_intl' => ['label' => 'رقم واتساب الدولي', 'type' => 'text', 'hint' => 'اتركه فارغًا إذا كان نفس رقم الهاتف'],
                'meta_description' => ['label' => 'وصف الموقع لمحركات البحث', 'type' => 'textarea'],
            ],
        ],
        'hero' => [
            'label' => 'الواجهة',
            'fields' => [
                'hero_eyebrow' => ['label' => 'السطر الصغير فوق العنوان', 'type' => 'text'],
                'hero_title' => ['label' => 'العنوان الرئيسي', 'type' => 'text'],
                'hero_highlight' => ['label' => 'الكلمة الملوّنة في آخر العنوان', 'type' => 'text'],
                'hero_lead' => ['label' => 'الوصف', 'type' => 'textarea'],
                'hero_cta' => ['label' => 'نص الزر الرئيسي', 'type' => 'text'],
                'hero_video' => ['label' => 'فيديو الخلفية', 'type' => 'video', 'hint' => 'MP4، يُفضّل أقل من 10 ميجابايت ومدة 10 إلى 20 ثانية'],
                'pass_from' => ['label' => 'بطاقة الصعود: من', 'type' => 'text'],
                'pass_to' => ['label' => 'بطاقة الصعود: إلى', 'type' => 'text'],
            ],
        ],
        'about' => [
            'label' => 'من نحن',
            'fields' => [
                'about_title' => ['label' => 'العنوان', 'type' => 'text'],
                'about_p1' => ['label' => 'الفقرة الأولى', 'type' => 'textarea'],
                'about_p2' => ['label' => 'الفقرة الثانية', 'type' => 'textarea'],
                'about_photo_1' => ['label' => 'الصورة الأولى', 'type' => 'image'],
                'about_photo_1_caption' => ['label' => 'عنوان الصورة الأولى', 'type' => 'text'],
                'about_photo_2' => ['label' => 'الصورة الثانية', 'type' => 'image'],
                'about_photo_2_caption' => ['label' => 'عنوان الصورة الثانية', 'type' => 'text'],
            ],
        ],
        'owner' => [
            'label' => 'المالك',
            'fields' => [
                'owner_name' => ['label' => 'اسم المالك', 'type' => 'text'],
                'owner_role' => ['label' => 'الصفة', 'type' => 'text'],
                'owner_photo' => ['label' => 'صورة المالك', 'type' => 'image', 'hint' => 'صورة مربعة، 400×400 بكسل أو أكبر'],
                'owner_bio' => ['label' => 'نبذة', 'type' => 'textarea'],
                'owner_quote' => ['label' => 'عبارة مقتبسة', 'type' => 'textarea', 'hint' => 'اتركها فارغة لإخفائها'],
            ],
        ],
        'sections' => [
            'label' => 'عناوين الأقسام',
            'fields' => [
                'services_title' => ['label' => 'الخدمات: العنوان', 'type' => 'text'],
                'services_lead' => ['label' => 'الخدمات: الوصف', 'type' => 'textarea'],
                'why_title' => ['label' => 'لماذا تختارنا: العنوان', 'type' => 'text'],
                'destinations_title' => ['label' => 'الوجهات: العنوان', 'type' => 'text'],
                'destinations_lead' => ['label' => 'الوجهات: الوصف', 'type' => 'textarea'],
                'board_note' => ['label' => 'ملاحظة لوحة المغادرة', 'type' => 'text'],
                'docs_title' => ['label' => 'المستندات: العنوان', 'type' => 'text'],
                'docs_lead' => ['label' => 'المستندات: الوصف', 'type' => 'textarea'],
                'docs_note' => ['label' => 'المستندات: ملاحظة أسفل القسم', 'type' => 'textarea'],
                'steps_title' => ['label' => 'طريقة الحجز: العنوان', 'type' => 'text'],
                'faq_title' => ['label' => 'الأسئلة الشائعة: العنوان', 'type' => 'text'],
                'booking_title' => ['label' => 'نموذج الحجز: العنوان', 'type' => 'text'],
                'booking_lead' => ['label' => 'نموذج الحجز: الوصف', 'type' => 'textarea'],
                'contact_title' => ['label' => 'التواصل: العنوان', 'type' => 'text'],
                'contact_lead' => ['label' => 'التواصل: الوصف', 'type' => 'textarea'],
            ],
        ],
        'footer' => [
            'label' => 'التذييل',
            'fields' => [
                'footer_about' => ['label' => 'نبذة في التذييل', 'type' => 'textarea'],
                'footer_credit' => ['label' => 'سطر حقوق الصور', 'type' => 'text', 'hint' => 'اتركه فارغًا إذا كانت كل الصور خاصة بكم'],
            ],
        ],
    ],

    'resources' => [
        'services' => [
            'model' => App\Models\Service::class,
            'label' => 'الخدمات',
            'singular' => 'خدمة',
            'list' => ['title' => 'الخدمة'],
            'fields' => [
                'title' => ['label' => 'اسم الخدمة', 'type' => 'text', 'rules' => 'required|string|max:120'],
                'description' => ['label' => 'الوصف', 'type' => 'textarea', 'rules' => 'nullable|string|max:1000'],
                'features' => ['label' => 'ما تشمله الخدمة', 'type' => 'lines', 'rules' => 'nullable|string|max:2000', 'hint' => 'كل سطر يظهر كنقطة منفصلة'],
                'icon' => ['label' => 'الأيقونة', 'type' => 'icon', 'rules' => 'required|string|max:40'],
                'sort_order' => ['label' => 'الترتيب', 'type' => 'number', 'rules' => 'nullable|integer|min:0|max:9999'],
                'is_active' => ['label' => 'ظاهرة في الموقع', 'type' => 'boolean'],
            ],
        ],
        'destinations' => [
            'model' => App\Models\Destination::class,
            'label' => 'الوجهات',
            'singular' => 'وجهة',
            'list' => ['city' => 'المدينة', 'country' => 'البلد', 'code' => 'الرمز'],
            'fields' => [
                'city' => ['label' => 'المدينة', 'type' => 'text', 'rules' => 'required|string|max:120'],
                'country' => ['label' => 'البلد', 'type' => 'text', 'rules' => 'nullable|string|max:120'],
                'code' => ['label' => 'رمز المطار', 'type' => 'text', 'rules' => 'nullable|string|max:8|regex:/^[A-Za-z]{2,8}$/', 'hint' => 'ثلاثة أحرف إنجليزية، مثل JED'],
                'subtitle' => ['label' => 'سطر تحت الاسم في معرض الصور', 'type' => 'text', 'rules' => 'nullable|string|max:120', 'hint' => 'إذا تُرك فارغًا يظهر اسم البلد'],
                'image' => ['label' => 'الصورة', 'type' => 'image'],
                'featured' => ['label' => 'اعرضها في معرض الصور (أول 4 وجهات لها صور)', 'type' => 'boolean'],
                'sort_order' => ['label' => 'الترتيب', 'type' => 'number', 'rules' => 'nullable|integer|min:0|max:9999'],
                'is_active' => ['label' => 'ظاهرة في الموقع', 'type' => 'boolean'],
            ],
        ],
        'features' => [
            'model' => App\Models\Feature::class,
            'label' => 'لماذا تختارنا',
            'singular' => 'ميزة',
            'list' => ['title' => 'الميزة'],
            'fields' => [
                'title' => ['label' => 'العنوان', 'type' => 'text', 'rules' => 'required|string|max:120'],
                'description' => ['label' => 'الوصف', 'type' => 'textarea', 'rules' => 'nullable|string|max:1000'],
                'icon' => ['label' => 'الأيقونة', 'type' => 'icon', 'rules' => 'required|string|max:40'],
                'sort_order' => ['label' => 'الترتيب', 'type' => 'number', 'rules' => 'nullable|integer|min:0|max:9999'],
                'is_active' => ['label' => 'ظاهرة في الموقع', 'type' => 'boolean'],
            ],
        ],
        'documents' => [
            'model' => App\Models\DocumentGroup::class,
            'label' => 'المستندات المطلوبة',
            'singular' => 'قائمة مستندات',
            'list' => ['title' => 'القائمة', 'tag' => 'الوسم'],
            'fields' => [
                'title' => ['label' => 'العنوان', 'type' => 'text', 'rules' => 'required|string|max:120'],
                'tag' => ['label' => 'وسم صغير بالإنجليزية', 'type' => 'text', 'rules' => 'nullable|string|max:20', 'hint' => 'مثل: VISA'],
                'items' => ['label' => 'المستندات', 'type' => 'lines', 'rules' => 'nullable|string|max:3000', 'hint' => 'كل سطر مستند'],
                'sort_order' => ['label' => 'الترتيب', 'type' => 'number', 'rules' => 'nullable|integer|min:0|max:9999'],
                'is_active' => ['label' => 'ظاهرة في الموقع', 'type' => 'boolean'],
            ],
        ],
        'steps' => [
            'model' => App\Models\Step::class,
            'label' => 'خطوات الحجز',
            'singular' => 'خطوة',
            'list' => ['title' => 'الخطوة'],
            'fields' => [
                'title' => ['label' => 'العنوان', 'type' => 'text', 'rules' => 'required|string|max:120'],
                'description' => ['label' => 'الوصف', 'type' => 'textarea', 'rules' => 'nullable|string|max:1000'],
                'sort_order' => ['label' => 'الترتيب', 'type' => 'number', 'rules' => 'nullable|integer|min:0|max:9999'],
                'is_active' => ['label' => 'ظاهرة في الموقع', 'type' => 'boolean'],
            ],
        ],
        'faqs' => [
            'model' => App\Models\Faq::class,
            'label' => 'الأسئلة الشائعة',
            'singular' => 'سؤال',
            'list' => ['question' => 'السؤال'],
            'fields' => [
                'question' => ['label' => 'السؤال', 'type' => 'text', 'rules' => 'required|string|max:255'],
                'answer' => ['label' => 'الإجابة', 'type' => 'textarea', 'rules' => 'required|string|max:3000'],
                'sort_order' => ['label' => 'الترتيب', 'type' => 'number', 'rules' => 'nullable|integer|min:0|max:9999'],
                'is_active' => ['label' => 'ظاهر في الموقع', 'type' => 'boolean'],
            ],
        ],
    ],

];
