@php
    $v = fn (string $key, string $default = '') => (isset($s[$key]) && $s[$key] !== '') ? $s[$key] : $default;
    $phone = $v('phone');
    $intl = preg_replace('/\D+/', '', $v('phone_intl'));
    $tel = $intl ? 'tel:+'.$intl : 'tel:'.$phone;
    $waDigits = preg_replace('/\D+/', '', $v('whatsapp_intl', $intl));
    $wa = $waDigits ? 'https://wa.me/'.$waDigits : null;
    $lines = fn (?string $text) => \App\Support\Text::lines($text);
    $arabicDigits = fn ($n) => strtr((string) $n, ['0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩']);
    $gallery = $destinations->filter(fn ($d) => $d->featured && $d->image)->take(4)->values();
    $bento = $gallery->count() === 4;
    $boardRows = $destinations->filter(fn ($d) => filled($d->code));
@endphp
<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>{{ $v('company_name', config('app.name')) }}</title>
    <meta name="description" content="{{ $v('meta_description') }}">
    <meta property="og:title" content="{{ $v('company_name') }}">
    <meta property="og:description" content="{{ $v('meta_description') }}">
    @if($v('owner_photo'))<meta property="og:image" content="{{ asset($v('owner_photo')) }}">@endif
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@500;600&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Reem+Kufi:wght@500;600;700&display=swap">
    <link rel="stylesheet" href="{{ asset('css/site.css') }}?v=3">
</head>
<body>

<header class="site-head">
    <div class="wrap">
        <a class="brand" href="#top" aria-label="{{ $v('company_name') }}">
            <span class="mark" aria-hidden="true">{{ $v('company_short', 'م ع') }}</span>
            <span class="brand-text">
                <strong>{{ $v('brand_name', $v('company_name')) }}</strong>
                <span>{{ $v('tagline') }}@if($v('city')) · {{ $v('city') }}@endif</span>
            </span>
        </a>
        <nav class="nav" aria-label="أقسام الصفحة">
            <a href="#about">من نحن</a>
            @if($services->isNotEmpty())<a href="#services">الخدمات</a>@endif
            @if($destinations->isNotEmpty())<a href="#destinations">الوجهات</a>@endif
            @if($documents->isNotEmpty())<a href="#documents">المستندات</a>@endif
            @if($v('owner_name'))<a href="#owner">المالك</a>@endif
            @if($faqs->isNotEmpty())<a href="#faq">الأسئلة</a>@endif
            <a href="#booking">اطلب حجزك</a>
        </nav>
        <a class="btn btn-sun head-call" href="{{ $tel }}">
            @include('site.partials.icon', ['name' => 'phone'])
            <span class="label">اتصل الآن</span>
        </a>
    </div>
</header>

<main id="top">

    {{-- Hero --}}
    <section class="hero">
        @if($v('hero_video'))
            <div class="hero-media" aria-hidden="true">
                <video id="heroVideo" src="{{ asset($v('hero_video')) }}" autoplay muted loop playsinline preload="auto"></video>
            </div>
            <button class="video-toggle" type="button" id="videoToggle" aria-pressed="false"><span class="vt-icon" aria-hidden="true">❚❚</span><span class="vt-label">إيقاف الفيديو</span></button>
        @endif
        <div class="wrap">
            <div class="hero-copy">
                @if($v('hero_eyebrow'))<span class="eyebrow">{{ $v('hero_eyebrow') }}</span>@endif
                <h1>{{ $v('hero_title') }} @if($v('hero_highlight'))<em>{{ $v('hero_highlight') }}</em>@endif</h1>
                @if($v('hero_lead'))<p class="lead">{{ $v('hero_lead') }}</p>@endif
                <div class="cta-row">
                    <a class="btn btn-sun" href="#booking">{{ $v('hero_cta', 'اطلب حجزك') }}</a>
                    <a class="btn btn-line" href="{{ $tel }}">
                        @include('site.partials.icon', ['name' => 'phone'])
                        اتصل بنا
                    </a>
                </div>
                @if($phone)<p class="hero-note">للحجز والاستفسار: <span class="num">{{ $phone }}</span></p>@endif
            </div>

            <div class="pass" aria-label="بطاقة صعود رمزية">
                <div class="pass-main">
                    <div class="pass-top">
                        <span class="t1">بطاقة صعود</span>
                        <span class="t2">BOARDING PASS</span>
                    </div>
                    <div class="route">
                        <div class="city"><small>من</small><b>{{ $v('pass_from', $v('city')) }}</b></div>
                        <div class="path" aria-hidden="true">
                            <svg class="plane" viewBox="0 0 24 24" fill="currentColor"><path transform="rotate(-90 12 12)" d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/></svg>
                        </div>
                        <div class="city to"><small>إلى</small><b>{{ $v('pass_to', 'وجهتك') }}</b></div>
                    </div>
                    <div class="fields">
                        <div class="field"><small>المسافر</small><span>أنت</span></div>
                        <div class="field"><small>الحجز</small><span>بالهاتف</span></div>
                        <div class="field"><small>المكتب</small><span>{{ $v('address') }}</span></div>
                    </div>
                </div>
                <div class="pass-stub">
                    <span class="stub-label">رقم الحجز</span>
                    <span class="stub-phone num">{{ $phone }}</span>
                    <span class="barcode" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </section>

    {{-- About --}}
    <section class="block alt" id="about">
        <div class="wrap about-grid">
            <div class="about-text">
                <div class="sec-head">
                    <span class="eyebrow">من نحن</span>
                    <h2>{{ $v('about_title') }}</h2>
                </div>
                @if($v('about_p1'))<p>{{ $v('about_p1') }}</p>@endif
                @if($v('about_p2'))<p>{{ $v('about_p2') }}</p>@endif
                @if($v('about_photo_1') || $v('about_photo_2'))
                    <div class="about-photos">
                        @foreach([1, 2] as $n)
                            @if($v("about_photo_{$n}"))
                                <figure class="ph">
                                    <img src="{{ asset($v("about_photo_{$n}")) }}" alt="{{ $v("about_photo_{$n}_caption") }}" style="object-position: center top;" loading="lazy">
                                    @if($v("about_photo_{$n}_caption"))<figcaption><b>{{ $v("about_photo_{$n}_caption") }}</b></figcaption>@endif
                                </figure>
                            @endif
                        @endforeach
                    </div>
                @endif
            </div>
            <dl class="facts">
                <div class="facts-title" style="border: 0; display: block;">بيانات الشركة</div>
                <div><dt>الاسم التجاري</dt><dd>{{ $v('company_name') }}</dd></div>
                @if($v('tagline'))<div><dt>النشاط</dt><dd>{{ $v('tagline') }}</dd></div>@endif
                @if($v('owner_name'))<div><dt>المالك</dt><dd>{{ $v('owner_name') }}</dd></div>@endif
                @if($v('address'))<div><dt>المقر</dt><dd>{{ $v('address') }}</dd></div>@endif
                @if($phone)<div><dt>الهاتف</dt><dd class="num">{{ $phone }}</dd></div>@endif
            </dl>
        </div>
    </section>

    {{-- Services --}}
    @if($services->isNotEmpty())
        <section class="block" id="services">
            <div class="wrap">
                <div class="sec-head">
                    <span class="eyebrow">خدماتنا</span>
                    <h2>{{ $v('services_title') }}</h2>
                    @if($v('services_lead'))<p>{{ $v('services_lead') }}</p>@endif
                </div>
                <div class="svc-grid">
                    @foreach($services as $service)
                        <article class="svc">
                            <span class="ico">@include('site.partials.icon', ['name' => $service->icon])</span>
                            <h3>{{ $service->title }}</h3>
                            @if($service->description)<p>{{ $service->description }}</p>@endif
                            @php($points = $lines($service->features))
                            @if($points->isNotEmpty())
                                <ul class="svc-list">
                                    @foreach($points as $point)<li>{{ $point }}</li>@endforeach
                                </ul>
                            @endif
                        </article>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- Why us --}}
    @if($features->isNotEmpty())
        <section class="block alt" id="why">
            <div class="wrap">
                <div class="sec-head">
                    <span class="eyebrow">لماذا تختارنا</span>
                    <h2>{{ $v('why_title') }}</h2>
                </div>
                <div class="why-grid">
                    @foreach($features as $feature)
                        <div class="why">
                            @include('site.partials.icon', ['name' => $feature->icon])
                            <h3>{{ $feature->title }}</h3>
                            @if($feature->description)<p>{{ $feature->description }}</p>@endif
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- Destinations --}}
    @if($destinations->isNotEmpty())
        <section class="block" id="destinations">
            <div class="wrap">
                <div class="sec-head">
                    <span class="eyebrow">الوجهات</span>
                    <h2>{{ $v('destinations_title') }}</h2>
                    @if($v('destinations_lead'))<p>{{ $v('destinations_lead') }}</p>@endif
                </div>

                @if($gallery->isNotEmpty())
                    <div @class(['gallery', 'gallery-simple' => ! $bento])>
                        @foreach($gallery as $i => $d)
                            <figure @class(['ph', 'ph-tall' => $bento && $i === 0, 'ph-wide' => $bento && $i === 3])>
                                <img src="{{ asset($d->image) }}" alt="{{ $d->city }}" loading="lazy">
                                <figcaption>
                                    <span><b>{{ $d->city }}</b><small>{{ $d->subtitle ?: $d->country }}</small></span>
                                    @if($d->code)<span class="tag-code">{{ $d->code }}</span>@endif
                                </figcaption>
                            </figure>
                        @endforeach
                    </div>
                @endif

                @if($boardRows->isNotEmpty())
                    <div class="board">
                        <div class="board-head">
                            <div class="board-title"><b>لوحة المغادرة</b><span>DEPARTURES</span></div>
                            <div class="clock"><small>توقيت السودان</small><span id="clock" class="num">--:--</span></div>
                        </div>
                        <div class="board-scroll">
                            <table>
                                <thead>
                                <tr><th scope="col">الرمز</th><th scope="col">الوجهة</th><th scope="col">البلد</th><th scope="col">الحجز</th></tr>
                                </thead>
                                <tbody>
                                @foreach($boardRows as $d)
                                    <tr>
                                        <td><span class="code" data-code="{{ $d->code }}"></span></td>
                                        <td class="dest"><b>{{ $d->city }}</b></td>
                                        <td class="country">{{ $d->country }}</td>
                                        <td><a class="status" href="#booking" style="text-decoration: none;">احجز الآن</a></td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        @if($v('board_note'))<p class="board-foot">{{ $v('board_note') }}</p>@endif
                    </div>
                @endif
            </div>
        </section>
    @endif

    {{-- Documents --}}
    @if($documents->isNotEmpty())
        <section class="block alt" id="documents">
            <div class="wrap">
                <div class="sec-head">
                    <span class="eyebrow">المستندات المطلوبة</span>
                    <h2>{{ $v('docs_title') }}</h2>
                    @if($v('docs_lead'))<p>{{ $v('docs_lead') }}</p>@endif
                </div>
                <div class="docs-grid">
                    @foreach($documents as $doc)
                        <article class="doc">
                            <div class="doc-head">
                                @if($doc->tag)<span class="tag">{{ $doc->tag }}</span>@endif
                                <h3>{{ $doc->title }}</h3>
                            </div>
                            <ul class="checks">
                                @foreach($lines($doc->items) as $line)<li>{{ $line }}</li>@endforeach
                            </ul>
                        </article>
                    @endforeach
                </div>
                @if($v('docs_note'))<p class="docs-note">{{ $v('docs_note') }}</p>@endif
            </div>
        </section>
    @endif

    {{-- Steps --}}
    @if($steps->isNotEmpty())
        <section class="block" id="how">
            <div class="wrap">
                <div class="sec-head">
                    <span class="eyebrow">طريقة الحجز</span>
                    <h2>{{ $v('steps_title') }}</h2>
                </div>
                <ol class="steps">
                    @foreach($steps as $step)
                        <li class="step">
                            <span class="n">{{ $arabicDigits($loop->iteration) }}</span>
                            <h3>{{ $step->title }}</h3>
                            @if($step->description)<p>{{ $step->description }}</p>@endif
                        </li>
                    @endforeach
                </ol>
            </div>
        </section>
    @endif

    {{-- Owner --}}
    @if($v('owner_name'))
        <section class="block alt" id="owner">
            <div class="wrap owner-grid">
                <div class="owner-card">
                    @if($v('owner_photo'))
                        <img class="owner-photo" src="{{ asset($v('owner_photo')) }}" alt="صورة {{ $v('owner_name') }}" width="144" height="144">
                    @endif
                    <h3>{{ $v('owner_name') }}</h3>
                    @if($v('owner_role'))<span class="owner-role">{{ $v('owner_role') }}</span>@endif
                    <dl class="owner-meta">
                        <div><dt>الشركة</dt><dd>{{ $v('brand_name', $v('company_name')) }}</dd></div>
                        @if($phone)<div><dt>الهاتف</dt><dd class="num">{{ $phone }}</dd></div>@endif
                        @if($v('address'))<div><dt>المكتب</dt><dd>{{ $v('address') }}</dd></div>@endif
                    </dl>
                    <div class="contact-actions" style="width: 100%; margin-top: 8px;">
                        <a class="btn btn-nile" href="{{ $tel }}">اتصل به</a>
                        @if($wa)<a class="btn btn-line" href="{{ $wa }}" target="_blank" rel="noopener">واتساب</a>@endif
                    </div>
                </div>
                <div class="owner-text">
                    <div class="sec-head">
                        <span class="eyebrow">مالك الشركة</span>
                        <h2>تعرّف على {{ $v('owner_name') }}</h2>
                    </div>
                    @if($v('owner_bio'))<p>{{ $v('owner_bio') }}</p>@endif
                    @if($v('owner_quote'))<blockquote>{{ $v('owner_quote') }}</blockquote>@endif
                </div>
            </div>
        </section>
    @endif

    {{-- FAQ --}}
    @if($faqs->isNotEmpty())
        <section class="block" id="faq">
            <div class="wrap">
                <div class="sec-head">
                    <span class="eyebrow">الأسئلة الشائعة</span>
                    <h2>{{ $v('faq_title') }}</h2>
                </div>
                <div class="faq">
                    @foreach($faqs as $faq)
                        <details @if($loop->first) open @endif>
                            <summary>{{ $faq->question }}</summary>
                            <p>{!! nl2br(e($faq->answer)) !!}</p>
                        </details>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- Booking form --}}
    <section class="block alt" id="booking">
        <div class="wrap booking-grid">
            <div class="booking-intro">
                <div class="sec-head">
                    <span class="eyebrow">اطلب حجزك</span>
                    <h2>{{ $v('booking_title', 'اطلب حجزك الآن') }}</h2>
                    @if($v('booking_lead'))<p>{{ $v('booking_lead') }}</p>@endif
                </div>
                <ul class="booking-points">
                    <li>نرد عليك بالاتصال أو عبر واتساب.</li>
                    <li>لا يُعتبر الطلب حجزًا نهائيًا حتى نؤكده معك.</li>
                    @if($phone)<li>للطلبات العاجلة اتصل مباشرة على <span class="num">{{ $phone }}</span>.</li>@endif
                </ul>
            </div>

            <form class="booking-card" method="post" action="{{ route('booking.store') }}" novalidate>
                @csrf
                @if(session('booked'))
                    <div class="form-ok" role="status">وصل طلبك. سنتصل بك قريبًا لتأكيد التفاصيل.</div>
                @elseif($errors->any())
                    <div class="form-bad" role="alert">لم يُرسل الطلب. راجع الحقول المعلّمة ثم أرسله مرة أخرى.</div>
                @endif

                <div class="hp" aria-hidden="true">
                    <label for="website">اترك هذا الحقل فارغًا</label>
                    <input id="website" name="website" type="text" tabindex="-1" autocomplete="off">
                </div>

                <div class="form-row">
                    <div @class(['fld', 'has-err' => $errors->has('name')])>
                        <label for="b_name">الاسم</label>
                        <input id="b_name" name="name" type="text" value="{{ old('name') }}" required maxlength="120" autocomplete="name">
                        @error('name')<span class="err">{{ $message }}</span>@enderror
                    </div>
                    <div @class(['fld', 'has-err' => $errors->has('phone')])>
                        <label for="b_phone">رقم الهاتف أو واتساب</label>
                        <input id="b_phone" name="phone" type="tel" value="{{ old('phone') }}" required maxlength="40" autocomplete="tel" dir="ltr">
                        @error('phone')<span class="err">{{ $message }}</span>@enderror
                    </div>
                </div>

                <div class="form-row">
                    <div @class(['fld', 'has-err' => $errors->has('service')])>
                        <label for="b_service">الخدمة</label>
                        <select id="b_service" name="service">
                            <option value="">اختر الخدمة</option>
                            @foreach($services as $service)
                                <option value="{{ $service->title }}" @selected(old('service') === $service->title)>{{ $service->title }}</option>
                            @endforeach
                            <option value="أخرى" @selected(old('service') === 'أخرى')>أخرى</option>
                        </select>
                        @error('service')<span class="err">{{ $message }}</span>@enderror
                    </div>
                    <div @class(['fld', 'has-err' => $errors->has('destination')])>
                        <label for="b_destination">الوجهة</label>
                        <input id="b_destination" name="destination" type="text" value="{{ old('destination') }}" maxlength="120" list="destinations-list">
                        <datalist id="destinations-list">
                            @foreach($destinations as $d)<option value="{{ $d->city }}"></option>@endforeach
                        </datalist>
                        @error('destination')<span class="err">{{ $message }}</span>@enderror
                    </div>
                </div>

                <div class="form-row">
                    <div @class(['fld', 'has-err' => $errors->has('travel_date')])>
                        <label for="b_date">تاريخ السفر <small>(اختياري)</small></label>
                        <input id="b_date" name="travel_date" type="date" value="{{ old('travel_date') }}" min="{{ now()->toDateString() }}">
                        @error('travel_date')<span class="err">{{ $message }}</span>@enderror
                    </div>
                    <div @class(['fld', 'has-err' => $errors->has('travelers')])>
                        <label for="b_travelers">عدد المسافرين</label>
                        <input id="b_travelers" name="travelers" type="number" min="1" max="200" value="{{ old('travelers', 1) }}">
                        @error('travelers')<span class="err">{{ $message }}</span>@enderror
                    </div>
                </div>

                <div @class(['fld', 'has-err' => $errors->has('notes')])>
                    <label for="b_notes">ملاحظات <small>(اختياري)</small></label>
                    <textarea id="b_notes" name="notes" maxlength="2000" placeholder="مثال: ذهاب وعودة، أفضّل رحلة مسائية">{{ old('notes') }}</textarea>
                    @error('notes')<span class="err">{{ $message }}</span>@enderror
                </div>

                <div class="form-foot">
                    <button class="btn btn-sun" type="submit">إرسال الطلب</button>
                    <small>نستخدم بياناتك للتواصل معك بخصوص هذا الطلب فقط.</small>
                </div>
            </form>
        </div>
    </section>

    {{-- Contact --}}
    <section class="contact" id="contact">
        <div class="wrap">
            <div>
                <span class="eyebrow" style="color: inherit;">تواصل معنا</span>
                <h2 style="margin-top: 10px;">{{ $v('contact_title') }}</h2>
                @if($v('contact_lead'))<p>{{ $v('contact_lead') }}</p>@endif
            </div>
            <div class="contact-card">
                @if($phone)
                    <div class="row">
                        <span class="ri">@include('site.partials.icon', ['name' => 'phone'])</span>
                        <div>
                            <small>رقم الهاتف</small>
                            <span class="num big-num" id="phone" data-copy="{{ $phone }}">{{ $phone }}</span>
                        </div>
                    </div>
                @endif
                @if($v('address'))
                    <div class="row">
                        <span class="ri">@include('site.partials.icon', ['name' => 'pin'])</span>
                        <div>
                            <small>العنوان</small>
                            <span style="font-weight: 600;">{{ $v('address') }}</span>
                        </div>
                    </div>
                @endif
                <div class="contact-actions">
                    <a class="btn btn-nile" href="{{ $tel }}">اتصال</a>
                    @if($wa)<a class="btn btn-line" href="{{ $wa }}" target="_blank" rel="noopener">واتساب</a>@endif
                    @if($phone)<button class="btn btn-line" type="button" id="copyBtn">نسخ الرقم</button>@endif
                </div>
                <span class="copy-msg" id="copyMsg" role="status" aria-live="polite"></span>
            </div>
        </div>
    </section>

</main>

<footer>
    <div class="wrap">
        <div class="foot-grid">
            <div class="foot-brand">
                <a class="brand" href="#top">
                    <span class="mark" aria-hidden="true">{{ $v('company_short', 'م ع') }}</span>
                    <span class="brand-text"><strong style="color: var(--ink);">{{ $v('brand_name', $v('company_name')) }}</strong><span>{{ $v('tagline') }}@if($v('city')) · {{ $v('city') }}@endif</span></span>
                </a>
                @if($v('footer_about'))<p>{{ $v('footer_about') }}</p>@endif
            </div>
            <div>
                <h4>روابط سريعة</h4>
                <ul>
                    <li><a href="#about">من نحن</a></li>
                    @if($services->isNotEmpty())<li><a href="#services">الخدمات</a></li>@endif
                    @if($documents->isNotEmpty())<li><a href="#documents">المستندات المطلوبة</a></li>@endif
                    @if($faqs->isNotEmpty())<li><a href="#faq">الأسئلة الشائعة</a></li>@endif
                    <li><a href="#booking">اطلب حجزك</a></li>
                </ul>
            </div>
            <div>
                <h4>تواصل معنا</h4>
                <ul>
                    @if($v('owner_name'))<li>المالك: {{ $v('owner_name') }}</li>@endif
                    @if($phone)<li>الهاتف: <span class="num">{{ $phone }}</span></li>@endif
                    @if($v('address'))<li>العنوان: {{ $v('address') }}</li>@endif
                </ul>
            </div>
        </div>
        <div class="foot-bottom">
            <span>© {{ $arabicDigits(now()->year) }} {{ $v('company_name') }}. جميع الحقوق محفوظة.</span>
            @if($v('footer_credit'))<span>{{ $v('footer_credit') }}</span>@endif
        </div>
    </div>
</footer>

<script src="{{ asset('js/site.js') }}?v=2"></script>
</body>
</html>
