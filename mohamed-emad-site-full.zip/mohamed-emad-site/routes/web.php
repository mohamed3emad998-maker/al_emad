<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\BookingController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ResourceController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\SiteController;
use Illuminate\Support\Facades\Route;

// Public site
Route::get('/', [SiteController::class, 'home'])->name('home');
Route::post('/booking', [SiteController::class, 'book'])->middleware('throttle:5,1')->name('booking.store');

// Laravel's "auth" middleware sends guests to the route named "login".
Route::redirect('/login', '/admin/login')->name('login');

// Admin panel
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:5,1')->name('login.attempt');

    Route::middleware('auth')->group(function () {
        Route::post('logout', [AuthController::class, 'logout'])->name('logout');
        Route::get('password', [AuthController::class, 'editPassword'])->name('password.edit');
        Route::put('password', [AuthController::class, 'updatePassword'])->name('password.update');

        Route::get('/', DashboardController::class)->name('dashboard');

        Route::get('settings/{group?}', [SettingsController::class, 'edit'])->name('settings.edit');
        Route::put('settings/{group}', [SettingsController::class, 'update'])->name('settings.update');

        Route::get('bookings', [BookingController::class, 'index'])->name('bookings.index');
        Route::get('bookings/{booking}', [BookingController::class, 'show'])->name('bookings.show');
        Route::patch('bookings/{booking}', [BookingController::class, 'update'])->name('bookings.update');
        Route::delete('bookings/{booking}', [BookingController::class, 'destroy'])->name('bookings.destroy');

        Route::get('content/{resource}', [ResourceController::class, 'index'])->name('resource.index');
        Route::get('content/{resource}/create', [ResourceController::class, 'create'])->name('resource.create');
        Route::post('content/{resource}', [ResourceController::class, 'store'])->name('resource.store');
        Route::get('content/{resource}/{id}/edit', [ResourceController::class, 'edit'])->whereNumber('id')->name('resource.edit');
        Route::put('content/{resource}/{id}', [ResourceController::class, 'update'])->whereNumber('id')->name('resource.update');
        Route::delete('content/{resource}/{id}', [ResourceController::class, 'destroy'])->whereNumber('id')->name('resource.destroy');
    });
});
