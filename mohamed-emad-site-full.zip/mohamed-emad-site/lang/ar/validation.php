<?php

// Arabic messages for the validation rules this site uses.
// Rules not listed here fall back to English.

return [
    'required' => 'حقل :attribute مطلوب.',
    'string' => 'حقل :attribute يجب أن يكون نصًا.',
    'email' => 'أدخل بريدًا إلكترونيًا صحيحًا.',
    'integer' => 'حقل :attribute يجب أن يكون رقمًا صحيحًا.',
    'boolean' => 'قيمة :attribute غير صحيحة.',
    'date' => 'حقل :attribute ليس تاريخًا صحيحًا.',
    'after_or_equal' => 'اختر في حقل :attribute تاريخ اليوم أو تاريخًا بعده.',
    'regex' => 'صيغة :attribute غير صحيحة.',
    'in' => 'القيمة المختارة في :attribute غير صحيحة.',
    'confirmed' => 'تأكيد :attribute لا يطابق.',
    'current_password' => 'كلمة المرور الحالية غير صحيحة.',
    'image' => 'حقل :attribute يجب أن يكون صورة.',
    'file' => 'حقل :attribute يجب أن يكون ملفًا.',
    'mimes' => 'نوع ملف :attribute غير مدعوم. الأنواع المسموحة: :values.',
    'mimetypes' => 'نوع ملف :attribute غير مدعوم. الأنواع المسموحة: :values.',
    'uploaded' => 'تعذّر رفع :attribute. غالبًا حجم الملف أكبر من الحد المسموح في إعدادات الخادم.',
    'min' => [
        'numeric' => 'أقل قيمة لحقل :attribute هي :min.',
        'string' => 'حقل :attribute يجب ألا يقل عن :min حروف.',
        'file' => 'حجم :attribute يجب ألا يقل عن :min كيلوبايت.',
        'array' => 'حقل :attribute يجب أن يحتوي :min عناصر على الأقل.',
    ],
    'max' => [
        'numeric' => 'أكبر قيمة لحقل :attribute هي :max.',
        'string' => 'حقل :attribute يجب ألا يزيد عن :max حرفًا.',
        'file' => 'حجم :attribute يجب ألا يزيد عن :max كيلوبايت.',
        'array' => 'حقل :attribute يجب ألا يحتوي أكثر من :max عناصر.',
    ],

    'attributes' => [
        'name' => 'الاسم',
        'phone' => 'رقم الهاتف',
        'service' => 'الخدمة',
        'destination' => 'الوجهة',
        'travel_date' => 'تاريخ السفر',
        'travelers' => 'عدد المسافرين',
        'notes' => 'الملاحظات',
        'email' => 'البريد الإلكتروني',
        'password' => 'كلمة المرور',
        'current_password' => 'كلمة المرور الحالية',
        'title' => 'العنوان',
        'description' => 'الوصف',
        'question' => 'السؤال',
        'answer' => 'الإجابة',
        'city' => 'المدينة',
        'country' => 'البلد',
        'code' => 'رمز المطار',
        'image' => 'الصورة',
        'icon' => 'الأيقونة',
        'sort_order' => 'الترتيب',
        'status' => 'الحالة',
    ],
];
